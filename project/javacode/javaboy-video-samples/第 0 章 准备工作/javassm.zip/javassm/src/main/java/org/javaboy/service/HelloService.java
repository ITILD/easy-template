package org.javaboy.service;

import org.springframework.stereotype.Service;

/**
 * @Author 江南一点雨
 * @Site www.javaboy.org 2019-07-15 22:21
 */
@Service
public class HelloService {
    public String sayHello() {
        return "hello javassm!";
    }
}
