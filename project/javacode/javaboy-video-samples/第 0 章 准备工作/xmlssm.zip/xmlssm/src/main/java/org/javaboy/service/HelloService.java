package org.javaboy.service;

import org.springframework.stereotype.Service;

/**
 * @Author 江南一点雨
 * @Site www.javaboy.org 2019-07-15 22:00
 */
@Service
public class HelloService {
    public String sayHello() {
        return "hello Java 极客技术！";
    }
}
